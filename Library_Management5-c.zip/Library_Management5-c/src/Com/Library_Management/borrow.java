package Com.Library_Management;

public interface borrow {
	    void borrowBook(book book, member member);
	}


