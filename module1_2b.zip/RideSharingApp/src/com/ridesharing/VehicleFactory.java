package com.ridesharing;

public abstract class VehicleFactory {
    public abstract Vehicle createVehicle();
}
