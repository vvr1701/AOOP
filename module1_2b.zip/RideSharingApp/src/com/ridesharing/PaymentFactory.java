package com.ridesharing;

public interface PaymentFactory {
    PaymentMethod createPaymentMethod();
}
