/**
 * 
 */
/**
 * 
 */
module SingletonLoggerProject {
}