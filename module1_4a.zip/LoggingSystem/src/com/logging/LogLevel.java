package com.logging;

public enum LogLevel {
    INFO, DEBUG, ERROR
}
