package com.ridesharing;

public interface PaymentMethod {
    void pay();
}
