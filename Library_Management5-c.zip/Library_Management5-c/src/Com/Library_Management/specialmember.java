package Com.Library_Management;

public class specialmember extends member {
	    public specialmember(String name, String memberId) {
	        super(name, memberId);
	    }

	   
	}


