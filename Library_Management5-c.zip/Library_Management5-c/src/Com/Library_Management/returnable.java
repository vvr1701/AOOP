package Com.Library_Management;

public interface returnable {
    void returnBook(book book, member member);
}
