package Com.Library_Management;


	public class member {
	    private String name;
	    private String memberId;

	    public member(String name, String memberId) {
	        this.name = name;
	        this.memberId = memberId;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getMemberId() {
	        return memberId;
	    }
	}


